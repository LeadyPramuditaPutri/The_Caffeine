<?php 
extract($_POST);
if(($username='admin') and ($password='admin'))
{
	echo "<script>alert('selamat anda berhasil login')
	location.href='./home.html';
	</script>";
}
else
{
	echo "<script>alert('Password atau Username salah')
	location.href='./index.php';
	</script>";
	
}
?>