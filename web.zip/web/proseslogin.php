<?php 
session_start();
require_once("koneksidb.php");
$username = $_POST['username'];
$pass = $_POST['password'];
$cekuser = mysql_query("SELECT * FROM user WHERE username = '$username'");
$jumlah = mysql_num_rows($cekuser);
$hasil = mysql_fetch_array($cekuser);
if($jumlah == 0) {
$_SESSION['username'] = $hasil['username'];
header('location:index.html');
}
?>