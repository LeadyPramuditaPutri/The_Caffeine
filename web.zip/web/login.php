<?php 
session_start();
if(isset($_SESSION['username'])) {
header('location:index.html'); }
require_once("koneksidb.php");
?>
<center>
<form action="proseslogin.php" method="post">

<meta charset="utf-8">
<title>The Caffeine</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
body,td,th {
	color: #FFF;
}
body {
	background-color: #F30;
}
.container table tr td h1 i {
	text-align: center;
}
</style>
</head>

<body>

<div class="container">
  <table width="991" height="490" border="0" align="center">
  <tr>
  	<td><br></br></td>
    </tr>
  <tr>
    <td width="915" height="151" align="center"><h1><i>The Caffeine</i></h1></td>
  </tr>
  <tr>
    <td height="333">  <form class="form-horizontal" action="/action_page.php">
    <div class="form-group">
         <label for="username">Username</label>
         <input id="username" class="form-control" placeholder="Username Anda" name="username" type="text" autofocus required>
    </div>
    <div class="form-group">
         <label for="username">Password</label>
        <input id="password" class="form-control" placeholder="Password Anda" name="password" type="password" value="" required>
    </div>
    </div>
	<div>
        <!-- Change this to a button or input when using this as a form -->
        <button class="btn btn-lg btn-success btn-block" type="submit">Login</button>
        </fieldset>
        </form>
    </div>
  </form></td>
  </tr>
</table>


</div>
</body>
</tbody>
</form>
</center>